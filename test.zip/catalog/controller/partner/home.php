<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalogPartner' not found in <b>/home/kusdomcom/public_html/catalog/controller/partner/home.php</b> on line <b>14</b><br />
