<br />
<b>Fatal error</b>:  Class 'Controller' not found in <b>/home/kusdomcom/public_html/catalog/controller/module/transactionx.php</b> on line <b>4</b><br />
