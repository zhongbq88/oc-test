<br />
<b>Fatal error</b>:  Class 'Controller' not found in <b>/home/kusdomcom/public_html/catalog/controller/module/pavsliderlayer.php</b> on line <b>11</b><br />
