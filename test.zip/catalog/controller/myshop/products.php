<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalogMyshop' not found in <b>/home/kusdomcom/public_html/catalog/controller/myshop/products.php</b> on line <b>27</b><br />
