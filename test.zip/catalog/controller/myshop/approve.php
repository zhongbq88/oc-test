<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalog' not found in <b>/home/kusdomcom/public_html/catalog/controller/myshop/approve.php</b> on line <b>4</b><br />
