<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalogMyshop' not found in <b>/home/kusdomcom/public_html/catalog/controller/myshop/product.php</b> on line <b>14</b><br />
