<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalogMyshop' not found in <b>/home/kusdomcom/public_html/catalog/controller/myshop/albums.php</b> on line <b>14</b><br />
