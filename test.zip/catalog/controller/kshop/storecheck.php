<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalog' not found in <b>/home/kusdomcom/public_html/catalog/controller/kshop/storecheck.php</b> on line <b>17</b><br />
