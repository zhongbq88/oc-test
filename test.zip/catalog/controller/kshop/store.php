<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalogKshop' not found in <b>/home/kusdomcom/public_html/catalog/controller/kshop/store.php</b> on line <b>17</b><br />
