<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalogKshop' not found in <b>/home/kusdomcom/public_html/catalog/controller/kshop/mydesign.php</b> on line <b>15</b><br />
