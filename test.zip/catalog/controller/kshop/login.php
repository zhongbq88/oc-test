<br />
<b>Fatal error</b>:  Class 'Controller' not found in <b>/home/kusdomcom/public_html/catalog/controller/kshop/login.php</b> on line <b>16</b><br />
