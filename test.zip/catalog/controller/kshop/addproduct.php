<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalogKshop' not found in <b>/home/kusdomcom/public_html/catalog/controller/kshop/addproduct.php</b> on line <b>5</b><br />
