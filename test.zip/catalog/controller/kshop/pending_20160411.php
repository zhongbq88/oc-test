<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalog' not found in <b>/home/kusdomcom/public_html/catalog/controller/kshop/pending_20160411.php</b> on line <b>14</b><br />
