<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalogKshop' not found in <b>/home/kusdomcom/public_html/catalog/controller/kshop/myproduct.php</b> on line <b>17</b><br />
