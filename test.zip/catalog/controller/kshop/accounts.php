<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalogKshop' not found in <b>/home/kusdomcom/public_html/catalog/controller/kshop/accounts.php</b> on line <b>12</b><br />
