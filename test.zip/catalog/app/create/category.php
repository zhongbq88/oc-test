<br />
<b>Fatal error</b>:  Class 'Controller' not found in <b>/home/kusdomcom/public_html/catalog/app/create/category.php</b> on line <b>5</b><br />
