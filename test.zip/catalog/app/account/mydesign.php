<br />
<b>Fatal error</b>:  Class 'ControllerBaseCatalogCustomer' not found in <b>/home/kusdomcom/public_html/catalog/app/account/mydesign.php</b> on line <b>7</b><br />
