<br />
<b>Fatal error</b>:  Class 'Controller' not found in <b>/home/kusdomcom/public_html/catalog/app/checkout/confirm.php</b> on line <b>14</b><br />
