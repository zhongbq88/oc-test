<br />
<b>Fatal error</b>:  Class 'Model' not found in <b>/home/kusdomcom/public_html/catalog/model/account/customer.php</b> on line <b>3</b><br />
